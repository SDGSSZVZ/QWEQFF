export default {
	"name": "mergeForkIdTransition",
	"comment": "Pre-merge hardfork to fork off non-upgraded clients",
	"url": "https://eips.ethereum.org/EIPS/eip-3675",
	"status": "Draft",
	"eips": []
}
 ;