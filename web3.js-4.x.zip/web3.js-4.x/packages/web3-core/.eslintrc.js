module.exports = {
	extends: '../../.eslintrc.js',
	parserOptions: {
		project: './tsconfig.esm.json',
		tsconfigRootDir: __dirname,
	},
};
